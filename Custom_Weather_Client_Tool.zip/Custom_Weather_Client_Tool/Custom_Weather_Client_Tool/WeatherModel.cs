﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Custom_Weather_Client_Tool
{
    internal class WeatherModel
    {
        private string _City { get; set; }

        private decimal _Latitude { get; set; }

        private decimal _Longitude { get; set; }

        public string City
        {
            set { _City = value; }
            get { return _City; }
        }
        public decimal Latitude
        {
            set { _Latitude = value; }
            get { return _Latitude; }
        }
        public decimal Longitude
        {
            set { _Longitude = value; }
            get { return _Longitude; }
        }

    }
}
