﻿// See https://aka.ms/new-console-template for more information

using Custom_Weather_Client_Tool;
using Newtonsoft.Json.Linq;

class Program { 
    static void Main(string[] args)
    {
        WeatherModel weatherModel = new WeatherModel();

        Console.WriteLine("Enter the city name: ");
        string city = Console.ReadLine();
        weatherModel.City = city;

        using (StreamReader r = new StreamReader("C:\Users\dell\source\repos\Custom_Weather_Client_Tool\Custom_Weather_Client_Tool\weather.json"))
        {
            var json = r.ReadToEnd();

            var jArray = JArray.Parse(json);

            foreach (var item in jArray)
            {
                
            }
        }

    }
}

