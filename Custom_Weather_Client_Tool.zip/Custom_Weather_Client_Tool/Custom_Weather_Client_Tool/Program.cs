﻿using Custom_Weather_Client_Tool;
using Newtonsoft.Json.Linq;

class Program { 
    static void Main(string[] args)
    {
        WeatherModel weatherModel = new WeatherModel();

        Console.WriteLine("Enter the city name: ");
        string city = Console.ReadLine();

        using (StreamReader r = new StreamReader("weather.json"))
        {
            var json = r.ReadToEnd();

            var jArray = JArray.Parse(json);
            bool flag = false;
            foreach (var item in jArray)
            {
                weatherModel.City = (string)item["city"];
                weatherModel.Latitude= Convert.ToDecimal(item["lat"]);
                weatherModel.Longitude = Convert.ToDecimal(item["lng"]);
                
                if (city.Equals(weatherModel.City,StringComparison.OrdinalIgnoreCase))
                {
                    flag = true;
                    Console.WriteLine("Latitude and Longitude of city {0} is : ( {1} , {2} )", weatherModel.City, weatherModel.Latitude,weatherModel.Longitude);
                    break;
                }
                
            }
            if(flag==false)
                Console.WriteLine("Invalid City");

        }

    }
}

